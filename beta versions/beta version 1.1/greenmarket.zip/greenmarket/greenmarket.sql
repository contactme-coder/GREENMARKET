-- ============================================================
--  GreenMarket – Base de données complète (fichier unique)
--  Filière : DEV 202 | Module : M107 / M201
--  Instructrice : LAFHAL Joairia
--
--  Ce fichier remplace TOUS les anciens fichiers (greenmarket.sql,
--  patch_categories.sql, patch_produits_terroir_nord.sql,
--  reset_produits_terroir_nord.sql). Il suffit d'importer CELUI-CI
--  pour reconstruire la base depuis zéro, produits du terroir du
--  Nord déjà inclus.
--
--  UTILISATION (phpMyAdmin) :
--   1. Onglet "Bases de données" → supprimer "greenmarket" si elle
--      existe déjà (ou laisser le DROP DATABASE ci-dessous le faire)
--   2. Onglet "SQL" (sans sélectionner de base au préalable) →
--      coller tout le contenu de ce fichier → Exécuter
-- ============================================================

DROP DATABASE IF EXISTS greenmarket;
CREATE DATABASE greenmarket CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE greenmarket;

-- ============================================================
-- TABLES
-- ============================================================

-- Table unique pour gérer l'authentification
CREATE TABLE compte (
   id               INT AUTO_INCREMENT PRIMARY KEY,
   nom              VARCHAR(100) NOT NULL,
   email            VARCHAR(150) NOT NULL UNIQUE,
   motpasse         VARCHAR(255) NOT NULL,
   role             ENUM('client','producteur','admin') NOT NULL DEFAULT 'client',
   statut           ENUM('actif','suspendu','en_attente') DEFAULT 'actif',
   date_inscription DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Table des catégories
CREATE TABLE categorie (
   idcat       INT AUTO_INCREMENT PRIMARY KEY,
   libelle     VARCHAR(100) NOT NULL UNIQUE,
   description TEXT
);

-- Table des produits
CREATE TABLE produit (
   reference    VARCHAR(15)    NOT NULL PRIMARY KEY,
   libelle      VARCHAR(150)   NOT NULL,
   description  TEXT,
   prixu        DECIMAL(10,2)  NOT NULL CHECK(prixu > 0),
   quantite     INT            DEFAULT 0,
   statut       ENUM('en_attente','valide','refuse') DEFAULT 'en_attente',
   dateachat    DATETIME       DEFAULT CURRENT_TIMESTAMP,
   idcateg      INT            NOT NULL,
   id_producteur INT           NOT NULL,
   image        VARCHAR(255),
   FOREIGN KEY(idcateg)       REFERENCES categorie(idcat) ON DELETE RESTRICT,
   FOREIGN KEY(id_producteur) REFERENCES compte(id)       ON DELETE CASCADE
);

-- Table principale des commandes
CREATE TABLE commande (
    idcom            INT AUTO_INCREMENT PRIMARY KEY,
    id_client        INT NOT NULL,
    montant_total    DECIMAL(10,2) NOT NULL,
    methode_paiement VARCHAR(50)  NOT NULL,
    statut           ENUM('en_attente','livree','annulee') DEFAULT 'en_attente',
    date_commande    DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_client) REFERENCES compte(id) ON DELETE CASCADE
);

-- Table de détail : produits par commande
CREATE TABLE commande_produit (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    idcom             INT NOT NULL,
    reference_produit VARCHAR(15) NOT NULL,
    quantite          INT NOT NULL,
    prix_unitaire     DECIMAL(10,2) NOT NULL,
    statut_livraison  ENUM('en_attente','livree') DEFAULT 'en_attente',
    FOREIGN KEY (idcom)             REFERENCES commande(idcom)   ON DELETE CASCADE,
    FOREIGN KEY (reference_produit) REFERENCES produit(reference) ON DELETE RESTRICT
);

-- ============================================================
-- COMPTES UTILISATEURS DE DÉMONSTRATION
-- Algorithme : bcrypt — compatible password_verify()
-- ============================================================

-- id=1 | Admin | Mot de passe : admin123
INSERT INTO compte (nom, email, motpasse, role, statut) VALUES (
   'Administrateur',
   'admin@greenmarket.ma',
   '$2y$12$7x.OqV45Yj4glwyVJHZ/r.L9efNZETaED5N96K4ERbRyKS4wQ1QzO',
   'admin',
   'actif'
);

-- id=2 | Producteur de démo | Mot de passe : prod2026
INSERT INTO compte (nom, email, motpasse, role, statut) VALUES (
   'Ferme Bio Amina',
   'amina@greenmarket.ma',
   '$2y$12$c6HkURujdSwyWV2irDV57uxOY6TXcs17UgF54RdZMNQQg.3itEV2u',
   'producteur',
   'actif'
);

-- id=3 | Client de démo | Mot de passe : client2026
INSERT INTO compte (nom, email, motpasse, role, statut) VALUES (
   'Yassine Benali',
   'yassine@gmail.com',
   '$2y$12$DRHBZ2asNNi2IngYBTNZMeLUKOvr5yO9bRX5ftZLrtBSpIvYXt7Ry',
   'client',
   'actif'
);

-- ============================================================
-- CATÉGORIES
-- ============================================================

INSERT INTO categorie (libelle, description) VALUES
('Fruits & Légumes',       'Produits frais du maraîchage biologique local'),
('Miel & Apiculture',      'Miels artisanaux, cire et produits de la ruche'),
('Huiles & Olives',        'Huile d''olive extra-vierge pressée à froid'),
('Produits Laitiers',      'Fromages fermiers, lait cru, yaourts artisanaux'),
('Épices & Aromates',      'Herbes séchées et épices du terroir marocain'),
('Céréales & Légumineuses','Blé, orge, lentilles et légumineuses biologiques'),
('Conserves & Confitures', 'Confitures maison, conserves de légumes locaux'),
('Artisanat & Bien-être',  'Savons naturels, cosmétiques bio, huiles essentielles');

-- ============================================================
-- PRODUITS DU TERROIR – RÉGION TANGER-TÉTOUAN-AL HOCEIMA
-- Plusieurs sont des IGP (Indication Géographique Protégée)
-- officiellement reconnues pour cette région par le Ministère
-- de l'Agriculture. Tous liés au producteur "Ferme Bio Amina".
-- 5 produits "valide" (visibles dans le catalogue public)
-- 1 produit "en_attente" (démonstration du workflow admin)
-- ============================================================

-- 1. Miel d'Arbousier du Jbel Moulay Abdeslam (IGP)
INSERT INTO produit (reference, libelle, description, prixu, quantite, statut, idcateg, id_producteur, image) VALUES (
    'MIE-ARB-001',
    'Miel d''Arbousier du Jbel Moulay Abdeslam (IGP)',
    'Miel rare bénéficiant de l''Indication Géographique Protégée (IGP), récolté sur les arbousiers sauvages du Jbel Moulay Abdeslam, entre Chefchaouen et Ouezzane. Sa saveur intense, légèrement amère et boisée, en fait un miel de caractère très recherché des connaisseurs.',
    120.00, 25, 'valide',
    (SELECT idcat FROM categorie WHERE libelle = 'Miel & Apiculture'),
    (SELECT id FROM compte WHERE email = 'amina@greenmarket.ma'),
    'https://commons.wikimedia.org/wiki/Special:FilePath/Honey_(Italian-miele)_in_a_jar.jpg?width=600'
);

-- 2. Huile d'Olive Vierge Extra d'Ouezzane (IGP)
INSERT INTO produit (reference, libelle, description, prixu, quantite, statut, idcateg, id_producteur, image) VALUES (
    'HUI-OUZ-001',
    'Huile d''Olive Vierge Extra d''Ouezzane (IGP)',
    'Huile pressée à froid issue des oliveraies d''Ouezzane, ville considérée comme la capitale marocaine de l''huile d''olive et titulaire de l''Indication Géographique Protégée. Faible acidité, saveur fruitée et légèrement piquante en fin de bouche.',
    75.00, 50, 'valide',
    (SELECT idcat FROM categorie WHERE libelle = 'Huiles & Olives'),
    (SELECT id FROM compte WHERE email = 'amina@greenmarket.ma'),
    'https://commons.wikimedia.org/wiki/Special:FilePath/Extra_Virgin_Olive_Oil.jpg?width=600'
);

-- 3. Amandes Douces du Rif (IGP)
INSERT INTO produit (reference, libelle, description, prixu, quantite, statut, idcateg, id_producteur, image) VALUES (
    'AMD-RIF-001',
    'Amandes Douces du Rif (IGP)',
    'Amandes décortiquées récoltées dans les vergers en terrasses des montagnes du Rif, autour de Chefchaouen et Al Hoceima. Couvertes par l''Indication Géographique Protégée "Amande du Rif", elles sont prisées pour leur goût riche, utilisées en pâtisserie et dans l''amlou traditionnel.',
    95.00, 40, 'valide',
    (SELECT idcat FROM categorie WHERE libelle = 'Fruits & Légumes'),
    (SELECT id FROM compte WHERE email = 'amina@greenmarket.ma'),
    'https://commons.wikimedia.org/wiki/Special:FilePath/Almonds_in_a_bowl.jpg?width=600'
);

-- 4. Thym Sauvage du Rif
INSERT INTO produit (reference, libelle, description, prixu, quantite, statut, idcateg, id_producteur, image) VALUES (
    'THY-RIF-001',
    'Thym Sauvage du Rif',
    'Thym sauvage cueilli à la main puis séché au soleil dans les forêts de la province de Chefchaouen, selon le savoir-faire traditionnel des Jbala en matière de plantes aromatiques et médicinales. Idéal en tisane ou comme aromate pour vos plats mijotés.',
    22.00, 80, 'valide',
    (SELECT idcat FROM categorie WHERE libelle = 'Épices & Aromates'),
    (SELECT id FROM compte WHERE email = 'amina@greenmarket.ma'),
    'https://commons.wikimedia.org/wiki/Special:FilePath/Spice_thyme.jpg?width=600'
);

-- 5. Fromage de Chèvre "Ajbane Chefchaouen" (IGP)
INSERT INTO produit (reference, libelle, description, prixu, quantite, statut, idcateg, id_producteur, image) VALUES (
    'FRO-CHE-001',
    'Fromage de Chèvre "Ajbane Chefchaouen" (IGP)',
    'Fromage frais de chèvre fabriqué artisanalement dans la province de Chefchaouen à partir de lait cru, selon une recette traditionnelle reconnue par l''Indication Géographique Protégée "Ajbane Chefchaouen". Texture fondante, goût doux et légèrement acidulé.',
    48.00, 35, 'valide',
    (SELECT idcat FROM categorie WHERE libelle = 'Produits Laitiers'),
    (SELECT id FROM compte WHERE email = 'amina@greenmarket.ma'),
    'https://commons.wikimedia.org/wiki/Special:FilePath/Crottins_de_ch%C3%A8vre_-_001.JPG?width=600'
);

-- 6. Figues Séchées de Chefchaouen — "en_attente" (démo workflow admin)
INSERT INTO produit (reference, libelle, description, prixu, quantite, statut, idcateg, id_producteur, image) VALUES (
    'FIG-SEC-001',
    'Figues Séchées de Chefchaouen',
    'Figues séchées au soleil, issues des figuiers séculaires de la province de Chefchaouen, qui concentre à elle seule près des deux tiers des vergers de la région Tanger-Tétouan-Al Hoceima. Naturellement sucrées, sans conservateurs ni sucre ajouté.',
    38.00, 50, 'en_attente',
    (SELECT idcat FROM categorie WHERE libelle = 'Conserves & Confitures'),
    (SELECT id FROM compte WHERE email = 'amina@greenmarket.ma'),
    'https://commons.wikimedia.org/wiki/Special:FilePath/A_closeup_of_fig_fruit.JPG?width=600'
);

-- ============================================================
-- RÉCAPITULATIF DES ACCÈS DE DÉMONSTRATION
-- ============================================================
-- Rôle           | Email                       | Mot de passe
-- Admin           | admin@greenmarket.ma        | admin123
-- Producteur      | amina@greenmarket.ma        | prod2026
-- Client          | yassine@gmail.com           | client2026
-- ============================================================
