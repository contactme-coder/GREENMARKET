<?php
include("preferences.php");
include("prodconnex.php");

if(!isset($_SESSION['panier'])) { $_SESSION['panier'] = []; }

if(isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['ref'])) {
    $ref = $_GET['ref'];
    $_SESSION['panier'][$ref] = isset($_SESSION['panier'][$ref]) ? $_SESSION['panier'][$ref] + 1 : 1;
    header("Location: catalogue.php?msgs=ok");
    exit;
}

try {
    $req = $c->query("SELECT p.*, c.libelle as nomcat FROM produit p JOIN categorie c ON p.idcateg = c.idcat WHERE p.statut = 'valide' ORDER BY p.dateachat DESC");
    $produits = $req->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) { $produits = []; }
$cart_count = array_sum($_SESSION['panier']);
?>
<!DOCTYPE html>
<html lang="<?= $lang_active ?>" dir="<?= $lang_active === 'ar' ? 'rtl' : 'ltr' ?>">
<head>
  <meta charset="UTF-8">
  <title>GreenMarket – <?= tr('cat') ?></title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    :root { --ivory: #f9f5ef; --cream2: #e8dfd0; --olive: #5c6b3a; --text: #1e1e18; --white: #ffffff; }
    body { font-family: sans-serif; background: var(--ivory); color: var(--text); transition: 0.3s; padding-top: 90px; }
    
    body.dark { background-color: #121212 !important; color: #f9f5ef !important; }
    body.dark .navbar { background: #1e1e1e !important; border-bottom: 1px solid #333; }
    body.dark .navbar a { color: #fff !important; }
    body.dark .product-card { background: #1e1e1e; border-color: #333; }

    .navbar { position: fixed; top: 0; left: 0; right: 0; height: 72px; display: flex; justify-content: space-between; align-items: center; padding: 0 40px; background: rgba(249,245,239,0.95); border-bottom: 1px solid var(--cream2); z-index: 100; }
    .nav-links { display: flex; gap: 20px; list-style: none; }
    .nav-links a { text-decoration: none; color: var(--text); font-weight: bold; text-transform: uppercase; font-size: 13px; }
    .products-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 25px; padding: 40px; }
    .product-card { background: var(--white); border: 1px solid var(--cream2); border-radius: 12px; overflow: hidden; }
  </style>
</head>
<body class="<?= $theme_actif ?>">

<nav class="navbar">
  <a href="acceuil.php" style="font-weight:bold; color:var(--olive); font-size:1.3rem; text-decoration:none;">GreenMarket</a>
  <ul class="nav-links">
    <li><a href="acceuil.php"><?= tr('home') ?></a></li>
    <li><a href="catalogue.php"><?= tr('cat') ?></a></li>
    <li><a href="boutique.php"><?= tr('shop') ?></a></li>
  </ul>
  
  <div style="display:flex; align-items:center; gap:20px;">
    <?php afficher_selecteurs(); ?>
    <a href="panier.php" style="text-decoration:none; color:inherit; font-weight:bold;">🛒 (<?= $cart_count ?>)</a>
  </div>
</nav>

<div class="products-grid">
  <?php foreach($produits as $p): ?>
    <div class="product-card">
      <img src="<?= htmlspecialchars($p['image']) ?>" style="width:100%; height:180px; object-fit:cover;">
      <div style="padding:15px;">
        <h4 style="margin-bottom:10px;"><?= htmlspecialchars($p['libelle']) ?></h4>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:15px;">
          <span style="font-weight:bold; color:var(--olive);"><?= htmlspecialchars($p['prixu']) ?> DH</span>
          <a href="catalogue.php?action=add&ref=<?= urlencode($p['reference']) ?>" style="background:var(--olive); color:white; padding:6px 12px; border-radius:6px; text-decoration:none; font-size:12px;">+ Add</a>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

</body>
</html>